(ns minilang.parser
  (:require [catparty.lexer :as lexer])
  (:require [catparty.parser :as p])
  (:require [catparty.prettyprint :as pp])
  (:require [minilang.lexer :as mlex]))

;; Forward declarations
(declare parse-statement-list)
(declare parse-primary)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Infix operators for precedence climbing
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(def precedence
  {:op_assign 0,
   :op_eq 1,
   :op_neq 1,
   :op_lt 2,
   :op_lte 2,
   :op_gt 2,
   :op_gte 2,
   :op_plus 3,
   :op_minus 3,
   :op_mul 4,
   :op_div 4,
   :op_exp 5})

(def associativity
  {:op_assign :right,
   :op_eq :left,
   :op_neq :left,
   :op_lt :left,
   :op_lte :left,
   :op_gt :left,
   :op_gte :left,
   :op_plus :left,
   :op_minus :left,
   :op_mul :left,
   :op_div :left,
   :op_exp :right})

;; Create a "parser context" that has the infix operators
(defn create-infix-context []
  {:operators (p/make-operators precedence associativity parse-primary)})


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Grammar productions for recursive descent parsing
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;; Parse a primary expression
;;
;; Parameters:
;;    token-seq - the input token sequence
;;
;; Returns: a SingleParseResult containing the primary expression
;; and the remaining input token sequence.
;;
(defn parse-primary [token-seq ctx]
  (let [[lexeme token-type] (lexer/next-token token-seq)]
    (case token-type
      :identifier  (p/do-production :primary [(p/expect :identifier)] token-seq ctx)
      :int_literal (p/do-production :primary [(p/expect :int_literal)] token-seq ctx)
      :str_literal (p/do-production :primary [(p/expect :str_literal)] token-seq ctx)
      :lparen      (p/do-production :primary [(p/expect :lparen) p/parse-infix-expression (p/expect :rparen)] token-seq ctx)
      (throw (RuntimeException. (str "Invalid token " token-type " looking for primary expression"))))))

;; Parse a variable declaration statement.
;;
;; Parameters:
;;   token-seq - the input token sequence
;;   ctx - the parse context
;;
;; Returns: a SingleParseResult with the :var_decl_statement parse node
;; and the remaining input token sequence.
;;
(defn parse-var-decl-statement [token-seq ctx]
  ; var_decl_statement -> ^ var identifier ;
  (p/do-production :var_decl_statement
                 [(p/expect :var) (p/expect :identifier) (p/expect :semicolon)]
                 token-seq ctx))

;; Parse an expression statement.
;;
;; Parameters:
;;   token-seq - the input token sequence
;;   ctx - the parse context
;;
;; Returns: a ParseResult with the :expression_statement parse node
;; and the remaining input token sequence.
;;
(defn parse-expression-statement [token-seq ctx]
  (p/do-production :expression_statement [p/parse-infix-expression (p/expect :semicolon)] token-seq ctx))

;; Parse an if or while statement.
;; These have more or less the same syntax.
;;
;; Parameters:
;;   token-seq - the input token sequence
;;   ctx - the parse context
;;
;; Returns: a ParseResult with the :if_statement or :while_statement parse node
;; and the remaining input token sequence.
;;
(defn parse-if-or-while-statement [token-seq ctx]
  (let [[lexeme kw] (lexer/next-token token-seq)
        lhs-symbol (if (= kw :if) :if_statement :while_statement)]
    (p/do-production lhs-symbol
                     [(p/expect kw)
                      (p/expect :lparen) p/parse-infix-expression (p/expect :rparen)
                      (p/expect :lbrace) parse-statement-list (p/expect :rbrace)]
                     token-seq ctx)))

;; Parse a statement.
;;
;; Parameters:
;;   token-seq - the input token sequence
;;   ctx - the parse context
;;
;; Returns: a SingleParseResult with the :statement parse node
;; and the remaining input token sequence.
;;
(defn parse-statement [token-seq ctx]
  (let [[lexeme token-type] (lexer/next-token token-seq)]
    (case token-type
      ; statement -> ^ var_decl_statement
      :var (p/do-production :statement [parse-var-decl-statement] token-seq ctx)
      ; statement -> ^ if_statement
      :if (p/do-production :statement [parse-if-or-while-statement] token-seq ctx)
      ; statement -> ^ while_statement
      :while (p/do-production :statement [parse-if-or-while-statement] token-seq ctx)
      ; statement -> ^ expression_statement
      (p/do-production :statement [parse-expression-statement] token-seq ctx))))

;; Parse a statement list.
;;
;; Parameters:
;;   token-seq - the input token sequence
;;   ctx - the parse context
;;
;; Returns: a SingleParseResult with the :statement_list parse node
;; and the remaining input token sequence.
;;
(defn parse-statement-list [token-seq ctx]
  ; The possibilities are:
  ;   statement_list -> ^ statement
  ;   statement_list -> ^ statement statement_list
  ; We'll start by just parsing a statement.
  (let [statement-result (p/do-production :statement_list [parse-statement] token-seq ctx)
        remaining-tokens (:tokens statement-result)]
    ; Did we reach the end of the input token sequence?
    (if (empty? (:tokens statement-result))
      ; End of input
      ; statement_list -> statement ^
      statement-result
      ; Not end of input, so look ahead to next token
      (let [[lexeme token-type] (first remaining-tokens)]
        ; If the next token is a right brace, then end the production
        (if (= :rbrace token-type)
          ; statement_list -> statement ^
          statement-result
          ; There is more input, so recursively parse another statement list
          ; statement_list -> statement ^ statement_list
          (p/continue-production statement-result [parse-statement-list] ctx))))))

;; Parse a unit.
;;
;; Parameters:
;;    token-seq - the input token sequence
;;   ctx - the parse context
;;
;; Returns: a SingleParseResult containing the :unit parse node and the
;; remaining input token sequence.
;;
(defn parse-unit [token-seq ctx]
  ; unit -> ^ statement_list
  (p/do-production :unit [parse-statement-list] token-seq ctx))

;; Top-level parse function. Returns a single node resulting from
;; parsing the given token sequence.
(defn parse
  [token-seq]
  (:node (parse-unit token-seq (create-infix-context))))


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Testing
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;; This is a handy way to test your parser: define a string containing
;; input, create a token sequence using a lexer, and then call the
;; parse function to parse the token sequence.
;;
;; Just uncomment the two lines below (def testprog ...) and (def prog ...)
;;
;; Suggestion: pretty print the result of the parse using
;;
;;    (pp/pretty-print parse-tree)

(def testprog "var a; var b; a := 4; b := 5; a + b * 3;")
(def parse-tree (parse (lexer/token-sequence (mlex/create-from-string testprog))))
